# 🏧 🔗

## 🔗 🔗

🌐 🔗 👥 ✔️ 👀 🔧 🔢 ⚖️ 🎓.

✋️ 📤 💪 💼 🌐❔ 👆 💚 💪 ⚒ 🔢 🔛 🔗, 🍵 ✔️ 📣 📚 🎏 🔢 ⚖️ 🎓.

➡️ 🌈 👈 👥 💚 ✔️ 🔗 👈 ✅ 🚥 🔢 🔢 `q` 🔌 🔧 🎚.

✋️ 👥 💚 💪 🔗 👈 🔧 🎚.

##  "🇧🇲" 👐

🐍 📤 🌌 ⚒ 👐 🎓 "🇧🇲".

🚫 🎓 ⚫️ (❔ ⏪ 🇧🇲), ✋️ 👐 👈 🎓.

👈, 👥 📣 👩‍🔬 `__call__`:

```Python hl_lines="10"
{!../../../docs_src/dependencies/tutorial011.py!}
```

👉 💼, 👉 `__call__` ⚫️❔ **FastAPI** 🔜 ⚙️ ✅ 🌖 🔢 &amp; 🎧-🔗, &amp; 👉 ⚫️❔ 🔜 🤙 🚶‍♀️ 💲 🔢 👆 *➡ 🛠️ 🔢* ⏪.

## 🔗 👐

&amp; 🔜, 👥 💪 ⚙️ `__init__` 📣 🔢 👐 👈 👥 💪 ⚙️ "🔗" 🔗:

```Python hl_lines="7"
{!../../../docs_src/dependencies/tutorial011.py!}
```

👉 💼, **FastAPI** 🏆 🚫 ⏱ 👆 ⚖️ 💅 🔃 `__init__`, 👥 🔜 ⚙️ ⚫️ 🔗 👆 📟.

## ✍ 👐

👥 💪 ✍ 👐 👉 🎓 ⏮️:

```Python hl_lines="16"
{!../../../docs_src/dependencies/tutorial011.py!}
```

&amp; 👈 🌌 👥 💪 "🔗" 👆 🔗, 👈 🔜 ✔️ `"bar"` 🔘 ⚫️, 🔢 `checker.fixed_content`.

## ⚙️ 👐 🔗

⤴️, 👥 💪 ⚙️ 👉 `checker` `Depends(checker)`, ↩️ `Depends(FixedContentQueryChecker)`, ↩️ 🔗 👐, `checker`, 🚫 🎓 ⚫️.

&amp; 🕐❔ ❎ 🔗, **FastAPI** 🔜 🤙 👉 `checker` 💖:

```Python
checker(q="somequery")
```

...&amp; 🚶‍♀️ ⚫️❔ 👈 📨 💲 🔗 👆 *➡ 🛠️ 🔢* 🔢 `fixed_content_included`:

```Python hl_lines="20"
{!../../../docs_src/dependencies/tutorial011.py!}
```

/// tip

🌐 👉 💪 😑 🎭. &amp; ⚫️ 💪 🚫 📶 🆑 ❔ ⚫️ ⚠.

👫 🖼 😫 🙅, ✋️ 🎦 ❔ ⚫️ 🌐 👷.

📃 🔃 💂‍♂, 📤 🚙 🔢 👈 🛠️ 👉 🎏 🌌.

🚥 👆 🤔 🌐 👉, 👆 ⏪ 💭 ❔ 👈 🚙 🧰 💂‍♂ 👷 🔘.

///
