# 🔬 🔗 ⏮️ 🔐

## 🔑 🔗 ⏮️ 🔬

📤 😐 🌐❔ 👆 💪 💚 🔐 🔗 ⏮️ 🔬.

👆 🚫 💚 ⏮️ 🔗 🏃 (🚫 🙆 🎧-🔗 ⚫️ 💪 ✔️).

↩️, 👆 💚 🚚 🎏 🔗 👈 🔜 ⚙️ 🕴 ⏮️ 💯 (🎲 🕴 🎯 💯), &amp; 🔜 🚚 💲 👈 💪 ⚙️ 🌐❔ 💲 ⏮️ 🔗 ⚙️.

### ⚙️ 💼: 🔢 🐕‍🦺

🖼 💪 👈 👆 ✔️ 🔢 🤝 🐕‍🦺 👈 👆 💪 🤙.

👆 📨 ⚫️ 🤝 &amp; ⚫️ 📨 🔓 👩‍💻.

👉 🐕‍🦺 5️⃣📆 🔌 👆 📍 📨, &amp; 🤙 ⚫️ 💪 ✊ ➕ 🕰 🌘 🚥 👆 ✔️ 🔧 🎁 👩‍💻 💯.

👆 🎲 💚 💯 🔢 🐕‍🦺 🕐, ✋️ 🚫 🎯 🤙 ⚫️ 🔠 💯 👈 🏃.

👉 💼, 👆 💪 🔐 🔗 👈 🤙 👈 🐕‍🦺, &amp; ⚙️ 🛃 🔗 👈 📨 🎁 👩‍💻, 🕴 👆 💯.

### ⚙️ `app.dependency_overrides` 🔢

👫 💼, 👆 **FastAPI** 🈸 ✔️ 🔢 `app.dependency_overrides`, ⚫️ 🙅 `dict`.

🔐 🔗 🔬, 👆 🚮 🔑 ⏮️ 🔗 (🔢), &amp; 💲, 👆 🔗 🔐 (➕1️⃣ 🔢).

&amp; ⤴️ **FastAPI** 🔜 🤙 👈 🔐 ↩️ ⏮️ 🔗.

```Python hl_lines="28-29  32"
{!../../../docs_src/dependency_testing/tutorial001.py!}
```

/// tip

👆 💪 ⚒ 🔗 🔐 🔗 ⚙️ 🙆 👆 **FastAPI** 🈸.

⏮️ 🔗 💪 ⚙️ *➡ 🛠️ 🔢*, *➡ 🛠️ 👨‍🎨* (🕐❔ 👆 🚫 ⚙️ 📨 💲), `.include_router()` 🤙, ♒️.

FastAPI 🔜 💪 🔐 ⚫️.

///

⤴️ 👆 💪 ⏲ 👆 🔐 (❎ 👫) ⚒ `app.dependency_overrides` 🛁 `dict`:

```Python
app.dependency_overrides = {}
```

/// tip

🚥 👆 💚 🔐 🔗 🕴 ⏮️ 💯, 👆 💪 ⚒ 🔐 ▶️ 💯 (🔘 💯 🔢) &amp; ⏲ ⚫️ 🔚 (🔚 💯 🔢).

///
