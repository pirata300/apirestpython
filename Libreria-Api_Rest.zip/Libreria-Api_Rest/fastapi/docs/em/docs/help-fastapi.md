# ℹ FastAPI - 🤚 ℹ

👆 💖 **FastAPI**❓

🔜 👆 💖 ℹ FastAPI, 🎏 👩‍💻, &amp; 📕 ❓

⚖️ 🔜 👆 💖 🤚 ℹ ⏮️ **FastAPI**❓

📤 📶 🙅 🌌 ℹ (📚 🔌 1️⃣ ⚖️ 2️⃣ 🖊).

&amp; 📤 📚 🌌 🤚 ℹ 💁‍♂️.

## 👱📔 📰

👆 💪 👱📔 (🐌) [**FastAPI &amp; 👨‍👧‍👦** 📰](newsletter.md){.internal-link target=_blank} 🚧 ℹ 🔃:

* 📰 🔃 FastAPI &amp; 👨‍👧‍👦 👶
* 🦮 👶
* ⚒ 👶
* 💔 🔀 👶
* 💁‍♂ &amp; 🎱 👶

## ⏩ FastAPI 🔛 👱📔

<a href="https://twitter.com/fastapi" class="external-link" target="_blank">⏩ 🐶 Fastapi 🔛 **👱📔**</a> 🤚 📰 📰 🔃 **FastAPI**. 👶

## ✴ **FastAPI** 📂

👆 💪 "✴" FastAPI 📂 (🖊 ✴ 🔼 🔝 ▶️️): <a href="https://github.com/fastapi/fastapi" class="external-link" target="_blank">https://github.com/fastapi/fastapi</a>. 👶 👶

❎ ✴, 🎏 👩‍💻 🔜 💪 🔎 ⚫️ 🌅 💪 &amp; 👀 👈 ⚫️ ✔️ ⏪ ⚠ 🎏.

## ⌚ 📂 🗃 🚀

👆 💪 "⌚" FastAPI 📂 (🖊 "⌚" 🔼 🔝 ▶️️): <a href="https://github.com/fastapi/fastapi" class="external-link" target="_blank">https://github.com/fastapi/fastapi</a>. 👶

📤 👆 💪 🖊 "🚀 🕴".

🔨 ⚫️, 👆 🔜 📨 📨 (👆 📧) 🕐❔ 📤 🆕 🚀 (🆕 ⏬) **FastAPI** ⏮️ 🐛 🔧 &amp; 🆕 ⚒.

## 🔗 ⏮️ 📕

👆 💪 🔗 ⏮️ <a href="https://tiangolo.com" class="external-link" target="_blank">👤 (🇹🇦 🇩🇬 / `tiangolo`)</a>, 📕.

👆 💪:

* <a href="https://github.com/tiangolo" class="external-link" target="_blank">⏩ 👤 🔛 **📂**</a>.
    * 👀 🎏 📂 ℹ 🏗 👤 ✔️ ✍ 👈 💪 ℹ 👆.
    * ⏩ 👤 👀 🕐❔ 👤 ✍ 🆕 📂 ℹ 🏗.
* <a href="https://twitter.com/tiangolo" class="external-link" target="_blank">⏩ 👤 🔛 **👱📔**</a> ⚖️ <a href="https://fosstodon.org/@tiangolo" class="external-link" target="_blank">☠</a>.
    * 💬 👤 ❔ 👆 ⚙️ FastAPI (👤 💌 👂 👈).
    * 👂 🕐❔ 👤 ⚒ 🎉 ⚖️ 🚀 🆕 🧰.
    * 👆 💪 <a href="https://twitter.com/fastapi" class="external-link" target="_blank">⏩ 🐶 Fastapi 🔛 👱📔</a> (🎏 🏧).
* <a href="https://www.linkedin.com/in/tiangolo/" class="external-link" target="_blank">🔗 ⏮️ 👤 🔛 **👱📔**</a>.
    * 👂 🕐❔ 👤 ⚒ 🎉 ⚖️ 🚀 🆕 🧰 (👐 👤 ⚙️ 👱📔 🌖 🛎 🤷 ♂).
* ✍ ⚫️❔ 👤 ✍ (⚖️ ⏩ 👤) 🔛 <a href="https://dev.to/tiangolo" class="external-link" target="_blank">**🇸🇲.**</a> ⚖️ <a href="https://medium.com/@tiangolo" class="external-link" target="_blank">**🔉**</a>.
    * ✍ 🎏 💭, 📄, &amp; ✍ 🔃 🧰 👤 ✔️ ✍.
    * ⏩ 👤 ✍ 🕐❔ 👤 ✍ 🕳 🆕.

## 👱📔 🔃 **FastAPI**

<a href="https://twitter.com/compose/tweet?text=I'm loving @fastapi because... https://github.com/fastapi/fastapi" class="external-link" target="_blank">👱📔 🔃 **FastAPI**</a> &amp; ➡️ 👤 &amp; 🎏 💭 ⚫️❔ 👆 💖 ⚫️. 👶

👤 💌 👂 🔃 ❔ **FastAPI** 💆‍♂ ⚙️, ⚫️❔ 👆 ✔️ 💖 ⚫️, ❔ 🏗/🏢 👆 ⚙️ ⚫️, ♒️.

## 🗳 FastAPI

* <a href="https://www.slant.co/options/34241/~fastapi-review" class="external-link" target="_blank">🗳 **FastAPI** 📐</a>.
* <a href="https://alternativeto.net/software/fastapi/" class="external-link" target="_blank">🗳 **FastAPI** 📱</a>.
* <a href="https://stackshare.io/pypi-fastapi" class="external-link" target="_blank">💬 👆 ⚙️ **FastAPI** 🔛 ℹ</a>.

## ℹ 🎏 ⏮️ ❔ 📂

👆 💪 🔄 &amp; ℹ 🎏 ⏮️ 👫 ❔:

* <a href="https://github.com/fastapi/fastapi/discussions/categories/questions?discussions_q=category%3AQuestions+is%3Aunanswered" class="external-link" target="_blank">📂 💬</a>
* <a href="https://github.com/fastapi/fastapi/issues?q=is%3Aissue+is%3Aopen+sort%3Aupdated-desc+label%3Aquestion+-label%3Aanswered+" class="external-link" target="_blank">📂 ❔</a>

📚 💼 👆 5️⃣📆 ⏪ 💭 ❔ 📚 ❔. 👶

🚥 👆 🤝 📚 👫👫 ⏮️ 👫 ❔, 👆 🔜 ▶️️ 🛂 [FastAPI 🕴](fastapi-people.md#_2){.internal-link target=_blank}. 👶

💭, 🏆 ⚠ ☝: 🔄 😇. 👫👫 👟 ⏮️ 👫 😩 &amp; 📚 💼 🚫 💭 🏆 🌌, ✋️ 🔄 🏆 👆 💪 😇. 👶

💭 **FastAPI** 👪 😇 &amp; 👍. 🎏 🕰, 🚫 🚫 🎭 ⚖️ 😛 🎭 ⤵ 🎏. 👥 ✔️ ✊ 💅 🔠 🎏.

---

📥 ❔ ℹ 🎏 ⏮️ ❔ (💬 ⚖️ ❔):

### 🤔 ❔

* ✅ 🚥 👆 💪 🤔 ⚫️❔ **🎯** &amp; ⚙️ 💼 👨‍💼 💬.

* ⤴️ ✅ 🚥 ❔ (⭕ 👪 ❔) **🆑**.

* 📚 💼 ❔ 💭 🔃 👽 ⚗ ⚪️➡️ 👩‍💻, ✋️ 📤 💪 **👍** 1️⃣. 🚥 👆 💪 🤔 ⚠ &amp; ⚙️ 💼 👍, 👆 💪 💪 🤔 👍 **🎛 ⚗**.

* 🚥 👆 💪 🚫 🤔 ❔, 💭 🌖 **ℹ**.

### 🔬 ⚠

🌅 💼 &amp; 🏆 ❔ 📤 🕳 🔗 👨‍💼 **⏮️ 📟**.

📚 💼 👫 🔜 🕴 📁 🧬 📟, ✋️ 👈 🚫 🥃 **🔬 ⚠**.

* 👆 💪 💭 👫 🚚 <a href="https://stackoverflow.com/help/minimal-reproducible-example" class="external-link" target="_blank">⭐, 🔬, 🖼</a>, 👈 👆 💪 **📁-📋** &amp; 🏃 🌐 👀 🎏 ❌ ⚖️ 🎭 👫 👀, ⚖️ 🤔 👫 ⚙️ 💼 👍.

* 🚥 👆 😟 💁‍♂️ 👍, 👆 💪 🔄 **✍ 🖼** 💖 👈 👆, 🧢 🔛 📛 ⚠. ✔️ 🤯 👈 👉 💪 ✊ 📚 🕰 &amp; ⚫️ 💪 👻 💭 👫 ✍ ⚠ 🥇.

### 🤔 ⚗

* ⏮️ 💆‍♂ 💪 🤔 ❔, 👆 💪 🤝 👫 💪 **❔**.

* 📚 💼, ⚫️ 👍 🤔 👫 **📈 ⚠ ⚖️ ⚙️ 💼**, ↩️ 📤 5️⃣📆 👍 🌌 ❎ ⚫️ 🌘 ⚫️❔ 👫 🔄.

### 💭 🔐

🚥 👫 📨, 📤 ↕ 🤞 👆 🔜 ✔️ ❎ 👫 ⚠, ㊗, **👆 💂**❗ 🦸

* 🔜, 🚥 👈 ❎ 👫 ⚠, 👆 💪 💭 👫:

    * 📂 💬: ™ 🏤 **❔**.
    * 📂 ❔: **🔐** ❔**.

## ⌚ 📂 🗃

👆 💪 "⌚" FastAPI 📂 (🖊 "⌚" 🔼 🔝 ▶️️): <a href="https://github.com/fastapi/fastapi" class="external-link" target="_blank">https://github.com/fastapi/fastapi</a>. 👶

🚥 👆 🖊 "👀" ↩️ "🚀 🕴" 👆 🔜 📨 📨 🕐❔ 👱 ✍ 🆕 ❔ ⚖️ ❔. 👆 💪 ✔ 👈 👆 🕴 💚 🚨 🔃 🆕 ❔, ⚖️ 💬, ⚖️ 🎸, ♒️.

⤴️ 👆 💪 🔄 &amp; ℹ 👫 ❎ 👈 ❔.

## 💭 ❔

👆 💪 <a href="https://github.com/fastapi/fastapi/discussions/new?category=questions" class="external-link" target="_blank">✍ 🆕 ❔</a> 📂 🗃, 🖼:

* 💭 **❔** ⚖️ 💭 🔃 **⚠**.
* 🤔 🆕 **⚒**.

**🗒**: 🚥 👆 ⚫️, ⤴️ 👤 🔜 💭 👆 ℹ 🎏. 👶

## 📄 🚲 📨

👆 💪 ℹ 👤 📄 🚲 📨 ⚪️➡️ 🎏.

🔄, 🙏 🔄 👆 🏆 😇. 👶

---

📥 ⚫️❔ ✔️ 🤯 &amp; ❔ 📄 🚲 📨:

### 🤔 ⚠

* 🥇, ⚒ 💭 👆 **🤔 ⚠** 👈 🚲 📨 🔄 ❎. ⚫️ 💪 ✔️ 📏 💬 📂 💬 ⚖️ ❔.

* 📤 👍 🤞 👈 🚲 📨 🚫 🤙 💪 ↩️ ⚠ 💪 ❎ **🎏 🌌**. ⤴️ 👆 💪 🤔 ⚖️ 💭 🔃 👈.

### 🚫 😟 🔃 👗

* 🚫 😟 💁‍♂️ 🌅 🔃 👜 💖 💕 📧 👗, 👤 🔜 🥬 &amp; 🔗 🛃 💕 ❎.

* 🚫 😟 🔃 👗 🚫, 📤 ⏪ 🏧 🧰 ✅ 👈.

&amp; 🚥 📤 🙆 🎏 👗 ⚖️ ⚖ 💪, 👤 🔜 💭 🔗 👈, ⚖️ 👤 🔜 🚮 💕 🔛 🔝 ⏮️ 💪 🔀.

### ✅ 📟

* ✅ &amp; ✍ 📟, 👀 🚥 ⚫️ ⚒ 🔑, **🏃 ⚫️ 🌐** &amp; 👀 🚥 ⚫️ 🤙 ❎ ⚠.

* ⤴️ **🏤** 💬 👈 👆 👈, 👈 ❔ 👤 🔜 💭 👆 🤙 ✅ ⚫️.

/// info

👐, 👤 💪 🚫 🎯 💙 🎸 👈 ✔️ 📚 ✔.

📚 🕰 ⚫️ ✔️ 🔨 👈 📤 🎸 ⏮️ 3️⃣, 5️⃣ ⚖️ 🌅 ✔, 🎲 ↩️ 📛 😌, ✋️ 🕐❔ 👤 ✅ 🎸, 👫 🤙 💔, ✔️ 🐛, ⚖️ 🚫 ❎ ⚠ 👫 🛄 ❎. 👶

, ⚫️ 🤙 ⚠ 👈 👆 🤙 ✍ &amp; 🏃 📟, &amp; ➡️ 👤 💭 🏤 👈 👆. 👶

///

* 🚥 🇵🇷 💪 📉 🌌, 👆 💪 💭 👈, ✋️ 📤 🙅‍♂ 💪 💁‍♂️ 😟, 📤 5️⃣📆 📚 🤔 ☝ 🎑 (&amp; 👤 🔜 ✔️ 👇 👍 👍 👶), ⚫️ 👻 🚥 👆 💪 🎯 🔛 ⚛ 👜.

### 💯

* ℹ 👤 ✅ 👈 🇵🇷 ✔️ **💯**.

* ✅ 👈 💯 **❌** ⏭ 🇵🇷. 👶

* ⤴️ ✅ 👈 💯 **🚶‍♀️** ⏮️ 🇵🇷. 👶

* 📚 🎸 🚫 ✔️ 💯, 👆 💪 **🎗** 👫 🚮 💯, ⚖️ 👆 💪 **🤔** 💯 👆. 👈 1️⃣ 👜 👈 🍴 🌅 🕰 &amp; 👆 💪 ℹ 📚 ⏮️ 👈.

* ⤴️ 🏤 ⚫️❔ 👆 🔄, 👈 🌌 👤 🔜 💭 👈 👆 ✅ ⚫️. 👶

## ✍ 🚲 📨

👆 💪 [📉](contributing.md){.internal-link target=_blank} ℹ 📟 ⏮️ 🚲 📨, 🖼:

* 🔧 🤭 👆 🔎 🔛 🧾.
* 💰 📄, 📹, ⚖️ 📻 👆 ✍ ⚖️ 🔎 🔃 FastAPI <a href="https://github.com/fastapi/fastapi/edit/master/docs/en/data/external_links.yml" class="external-link" target="_blank">✍ 👉 📁</a>.
    * ⚒ 💭 👆 🚮 👆 🔗 ▶️ 🔗 📄.
* ℹ [💬 🧾](contributing.md#_9){.internal-link target=_blank} 👆 🇪🇸.
    * 👆 💪 ℹ 📄 ✍ ✍ 🎏.
* 🛠️ 🆕 🧾 📄.
* 🔧 ♻ ❔/🐛.
    * ⚒ 💭 🚮 💯.
* 🚮 🆕 ⚒.
    * ⚒ 💭 🚮 💯.
    * ⚒ 💭 🚮 🧾 🚥 ⚫️ 🔗.

## ℹ 🚧 FastAPI

ℹ 👤 🚧 **FastAPI**❗ 👶

📤 📚 👷, &amp; 🏆 ⚫️, **👆** 💪 ⚫️.

👑 📋 👈 👆 💪 ▶️️ 🔜:

* [ℹ 🎏 ⏮️ ❔ 📂](#i){.internal-link target=_blank} (👀 📄 🔛).
* [📄 🚲 📨](#i){.internal-link target=_blank} (👀 📄 🔛).

👈 2️⃣ 📋 ⚫️❔ **🍴 🕰 🏆**. 👈 👑 👷 🏆 FastAPI.

🚥 👆 💪 ℹ 👤 ⏮️ 👈, **👆 🤝 👤 🚧 FastAPI** &amp; ⚒ 💭 ⚫️ 🚧 **🛠️ ⏩ &amp; 👻**. 👶

## 🛑 💬

🛑 👶 <a href="https://discord.gg/VQjSZaeJmf" class="external-link" target="_blank">😧 💬 💽</a> 👶 &amp; 🤙 👅 ⏮️ 🎏 FastAPI 👪.

/// tip

❔, 💭 👫 <a href="https://github.com/fastapi/fastapi/discussions/new?category=questions" class="external-link" target="_blank">📂 💬</a>, 📤 🌅 👍 🤞 👆 🔜 📨 ℹ [FastAPI 🕴](fastapi-people.md#_2){.internal-link target=_blank}.

⚙️ 💬 🕴 🎏 🏢 💬.

///

### 🚫 ⚙️ 💬 ❔

✔️ 🤯 👈 💬 ✔ 🌅 "🆓 💬", ⚫️ ⏩ 💭 ❔ 👈 💁‍♂️ 🏢 &amp; 🌅 ⚠ ❔,, 👆 💪 🚫 📨 ❔.

📂, 📄 🔜 🦮 👆 ✍ ▶️️ ❔ 👈 👆 💪 🌖 💪 🤚 👍 ❔, ⚖️ ❎ ⚠ 👆 ⏭ 💬. &amp; 📂 👤 💪 ⚒ 💭 👤 🕧 ❔ 🌐, 🚥 ⚫️ ✊ 🕰. 👤 💪 🚫 🤙 👈 ⏮️ 💬 ⚙️. 👶

💬 💬 ⚙️ 🚫 💪 📇 📂, ❔ &amp; ❔ 5️⃣📆 🤚 💸 💬. &amp; 🕴 🕐 📂 💯 ▶️️ [FastAPI 🕴](fastapi-people.md#_2){.internal-link target=_blank}, 👆 🔜 🌅 🎲 📨 🌅 🙋 📂.

🔛 🎏 🚄, 📤 💯 👩‍💻 💬 ⚙️, 📤 ↕ 🤞 👆 🔜 🔎 👱 💬 📤, 🌖 🌐 🕰. 👶

## 💰 📕

👆 💪 💰 🐕‍🦺 📕 (👤) 🔘 <a href="https://github.com/sponsors/tiangolo" class="external-link" target="_blank">📂 💰</a>.

📤 👆 💪 🛍 👤 ☕ 👶 👶 💬 👏. 👶

&amp; 👆 💪 ▶️️ 🥇1st ⚖️ 🌟 💰 FastAPI. 👶 👶

## 💰 🧰 👈 🏋️ FastAPI

👆 ✔️ 👀 🧾, FastAPI 🧍 🔛 ⌚ 🐘, 💃 &amp; Pydantic.

👆 💪 💰:

* <a href="https://github.com/sponsors/samuelcolvin" class="external-link" target="_blank">✡ 🍏 (Pydantic)</a>
* <a href="https://github.com/sponsors/encode" class="external-link" target="_blank">🗜 (💃, Uvicorn)</a>

---

👏 ❗ 👶
